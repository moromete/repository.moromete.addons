# service.cinemagia

Kodi addon module to scrap program guide (epg) from cinemagia.ro and export it to xml file to be used in:
script.tvguide.fullscreen addon
https://github.com/primaeval/script.tvguide.fullscreen
