plugin.video.acestreamsearch
====================

Kodi plugin for searching https://acestreamsearch.net/

Play streams based on acestream engine installed locally or remote.
