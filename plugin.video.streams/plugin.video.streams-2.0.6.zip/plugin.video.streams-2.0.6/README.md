plugin.video.streams
====================

streams plugin for kodi

https://github.com/moromete/plugin.video.streams/wiki