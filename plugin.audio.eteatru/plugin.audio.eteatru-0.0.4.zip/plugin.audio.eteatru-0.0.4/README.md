plugin.audio.eteatru
====================

eteatru plugin for kodi
