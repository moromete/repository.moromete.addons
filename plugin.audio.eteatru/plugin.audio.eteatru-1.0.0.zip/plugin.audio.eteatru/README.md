plugin.audio.eteatru
====================

eteatru plugin for kodi

To get automatic updates for this plugin I recommend to install first
the following repository:

http://streams.magazinmixt.ro/repository/repository.moromete.addons.zip

then install "eteatru" add-on from "Music add-ons" section of this repository.