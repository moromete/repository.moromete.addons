plugin.video.digionline
====================

Watch Tv based on your DigiOnline account

https://github.com/moromete/plugin.video.digionline/wiki


To setup addon more easier use Chrome extension: chrome.cookie.digionline

https://github.com/moromete/chrome.cookie.digionline

or firefox extension: digionline-cookie-for-kodi

https://addons.mozilla.org/en-US/firefox/addon/digionline-cookie-for-kodi/



